<?php
/* Smarty version 4.4.1, created on 2024-03-02 17:51:00
  from 'C:\xampp\htdocs\dwes04\plantillas\enlaceFormularioNuevoTaller.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e358f4422c77_44756855',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '96024550256dfda93a08e891e637e24677c31bdd' => 
    array (
      0 => 'C:\\xampp\\htdocs\\dwes04\\plantillas\\enlaceFormularioNuevoTaller.tpl',
      1 => 1708796025,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e358f4422c77_44756855 (Smarty_Internal_Template $_smarty_tpl) {
?><h2>
    <a href="index.php?accion=nuevo_taller_form">Click aquí para añadir
        nuevo taller</a>
</h2><?php }
}
