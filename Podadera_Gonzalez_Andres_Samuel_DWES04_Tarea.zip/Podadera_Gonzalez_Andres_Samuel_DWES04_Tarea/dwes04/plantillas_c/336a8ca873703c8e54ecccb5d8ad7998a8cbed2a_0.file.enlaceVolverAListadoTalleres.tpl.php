<?php
/* Smarty version 4.4.1, created on 2024-03-02 23:35:25
  from 'C:\xampp\htdocs\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\dwes04\plantillas\enlaceVolverAListadoTalleres.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a9ad2118b4_25188560',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '336a8ca873703c8e54ecccb5d8ad7998a8cbed2a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\\dwes04\\plantillas\\enlaceVolverAListadoTalleres.tpl',
      1 => 1709393454,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a9ad2118b4_25188560 (Smarty_Internal_Template $_smarty_tpl) {
?><a href='index.php'>Volver al listado de talleres</a><?php }
}
