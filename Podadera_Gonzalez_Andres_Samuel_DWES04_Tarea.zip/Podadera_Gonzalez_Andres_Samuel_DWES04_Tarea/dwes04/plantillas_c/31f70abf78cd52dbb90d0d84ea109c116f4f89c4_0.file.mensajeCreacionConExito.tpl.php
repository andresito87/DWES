<?php
/* Smarty version 4.4.1, created on 2024-03-02 17:56:36
  from 'C:\xampp\htdocs\dwes04\plantillas\mensajeCreacionConExito.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e35a443c2ad3_45669545',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '31f70abf78cd52dbb90d0d84ea109c116f4f89c4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\dwes04\\plantillas\\mensajeCreacionConExito.tpl',
      1 => 1709393367,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:enlaceVolverAListadoTalleres.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_65e35a443c2ad3_45669545 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Aviso de creación de taller"), 0, false);
?>
<h1>Taller con id <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
 creado correctamente.</h1>
<?php $_smarty_tpl->_subTemplateRender("file:enlaceVolverAListadoTalleres.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
