<?php
/* Smarty version 4.4.1, created on 2024-03-02 17:56:54
  from 'C:\xampp\htdocs\dwes04\plantillas\formularioEditarTaller.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e35a561034e7_14843963',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bc336e9cc95802e5939e1f604b2a69f56a5c7783' => 
    array (
      0 => 'C:\\xampp\\htdocs\\dwes04\\plantillas\\formularioEditarTaller.tpl',
      1 => 1709398580,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:mostrarErrores.tpl' => 1,
    'file:enlaceVolverAListadoTalleres.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_65e35a561034e7_14843963 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Formulario de Creación de un nuevo Taller"), 0, false);
if ((isset($_smarty_tpl->tpl_vars['errores']->value)) && $_smarty_tpl->tpl_vars['errores']->value != null) {?>
    <?php $_smarty_tpl->_subTemplateRender("file:mostrarErrores.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}?>
<div>
    <!--  Aunque los datos son verificados del lado del servidor, añado una sutíl comprobación con el atributo required en HTML   -->
    <h1>Modifique los datos del taller:</h1>
    <?php if ((isset($_smarty_tpl->tpl_vars['taller']->value))) {?>
        <?php $_smarty_tpl->_assignInScope('id', $_smarty_tpl->tpl_vars['taller']->value->getId());?>
        <?php $_smarty_tpl->_assignInScope('nombre', $_smarty_tpl->tpl_vars['taller']->value->getNombre());?>
        <?php $_smarty_tpl->_assignInScope('descripcion', $_smarty_tpl->tpl_vars['taller']->value->getDescripcion());?>
        <?php $_smarty_tpl->_assignInScope('ubicacion', $_smarty_tpl->tpl_vars['taller']->value->getUbicacion());?>
        <?php $_smarty_tpl->_assignInScope('dia_semana', $_smarty_tpl->tpl_vars['taller']->value->getDiaSemana());?>
        <?php $_smarty_tpl->_assignInScope('hora_inicio', $_smarty_tpl->tpl_vars['taller']->value->getHoraInicio());?>
        <?php $_smarty_tpl->_assignInScope('hora_fin', $_smarty_tpl->tpl_vars['taller']->value->getHoraFin());?>
        <?php $_smarty_tpl->_assignInScope('cupo_maximo', $_smarty_tpl->tpl_vars['taller']->value->getCupoMaximo());?>
        <form class="nuevoTaller" action="index.php?accion=editar_taller" method="post">
            <?php if ((isset($_smarty_tpl->tpl_vars['id']->value))) {?>
                <input type="hidden" name="id" id="id" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
            <?php }?>
            <label for="nombre">Nombre:</label>
            <?php if ((isset($_smarty_tpl->tpl_vars['nombre']->value))) {?>
                <input type=" text" name="nombre" id="nombre" value="<?php echo $_smarty_tpl->tpl_vars['nombre']->value;?>
">
            <?php }?>
            <br>
            <label for="descripcion">Descripción:</label>
            <?php if ((isset($_smarty_tpl->tpl_vars['descripcion']->value))) {?>
                <input type="text" name="descripcion" id="descripcion" value="<?php echo $_smarty_tpl->tpl_vars['descripcion']->value;?>
">
            <?php }?>
            <br>
            <label for="ubicacion">Ubicación:</label>
            <?php if ((isset($_smarty_tpl->tpl_vars['ubicacion']->value))) {?>
                <input type="text" name="ubicacion" id="ubicacion" value="<?php echo $_smarty_tpl->tpl_vars['ubicacion']->value;?>
">
            <?php }?>
            <br>
            <label for="dia_semana">Día de la semana:</label>
            <select name="dia_semana" id="dia_semana">
                <?php if ((isset($_smarty_tpl->tpl_vars['dia_semana']->value))) {?>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['dias_validos']->value, 'dia');
$_smarty_tpl->tpl_vars['dia']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['dia']->value) {
$_smarty_tpl->tpl_vars['dia']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['dia']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['dia']->value == $_smarty_tpl->tpl_vars['dia_semana']->value) {?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['dia']->value;?>
</option>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                <?php }?>
            </select>
            <br>
            <label for="hora_inicio">Hora de Inicio:</label>
            <?php if ((isset($_smarty_tpl->tpl_vars['hora_inicio']->value))) {?>
                <input type="time" name="hora_inicio" id="hora_inicio" value="<?php echo $_smarty_tpl->tpl_vars['hora_inicio']->value->format('H:i');?>
">
            <?php }?>
            <br>
            <label for="hora_fin">Hora de Fin:</label>
            <?php if ((isset($_smarty_tpl->tpl_vars['hora_fin']->value))) {?>
                <input type="time" name="hora_fin" id="hora_fin" value="<?php echo $_smarty_tpl->tpl_vars['hora_fin']->value->format('H:i');?>
">
            <?php }?>
            <br>
            <label for="cupo_maximo">Cupo Máximo:</label>
            <?php if ((isset($_smarty_tpl->tpl_vars['cupo_maximo']->value))) {?>
                <input type="text" name="cupo_maximo" id="cupo_maximo" value="<?php echo $_smarty_tpl->tpl_vars['cupo_maximo']->value;?>
">
            <?php }?>
            <br>
            <input type="submit" value="Guardar">
        </form>
    <?php } else { ?>
        <p>ERROR en los datos recibidos.</p>
    <?php }?>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:enlaceVolverAListadoTalleres.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
