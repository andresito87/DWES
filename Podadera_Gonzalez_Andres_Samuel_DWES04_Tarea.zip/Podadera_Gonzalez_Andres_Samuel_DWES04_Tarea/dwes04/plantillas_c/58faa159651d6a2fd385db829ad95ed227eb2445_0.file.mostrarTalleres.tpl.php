<?php
/* Smarty version 4.4.1, created on 2024-03-02 22:16:47
  from '/var/www/html/plantillas/mostrarTalleres.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a54f6908b4_96215685',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '58faa159651d6a2fd385db829ad95ed227eb2445' => 
    array (
      0 => '/var/www/html/plantillas/mostrarTalleres.tpl',
      1 => 1709392798,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:mostrarErrores.tpl' => 1,
    'file:formularioFiltrarDia.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_65e3a54f6908b4_96215685 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'/var/www/html/vendor/smarty/smarty/libs/plugins/modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Listado de Talleres"), 0, false);
if ((isset($_smarty_tpl->tpl_vars['errores']->value)) && $_smarty_tpl->tpl_vars['errores']->value != null) {?>
    <?php $_smarty_tpl->_subTemplateRender("file:mostrarErrores.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
if ((isset($_smarty_tpl->tpl_vars['mostrarFormularioFiltrarDia']->value)) && 'mostrarFormularioFiltrarDia' == true) {?>
    <?php $_smarty_tpl->_subTemplateRender("file:formularioFiltrarDia.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}?>
<h1>Listado de Talleres</h1>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Ubicación</th>
            <th>Día de la Semana</th>
            <th>Hora de Inicio</th>
            <th>Hora de Fin</th>
            <th>Cupo Máximo</th>
            <th>Editar/Eliminar</th>
        </tr>
    </thead>
    <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['talleres']->value, 'taller');
$_smarty_tpl->tpl_vars['taller']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['taller']->value) {
$_smarty_tpl->tpl_vars['taller']->do_else = false;
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['taller']->value->getId();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['taller']->value->getNombre();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['taller']->value->getDescripcion();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['taller']->value->getUbicacion();?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['taller']->value->getDiaSemana();?>
</td>
                <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['taller']->value->getHoraInicio(),"%H:%M");?>
</td>
                <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['taller']->value->getHoraFin(),"%H:%M");?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['taller']->value->getCupoMaximo();?>
</td>
                <td>
                    <form action="index.php?accion=editar_taller_form" method="post">
                        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['taller']->value->getId();?>
">
                        <button id="editar" type="submit" value="Editar">Editar</button>
                    </form>
                    <form action="index.php?accion=borrar_taller" method="post">
                        <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['taller']->value->getId();?>
">
                        <button class="eliminar" type="submit" value="Eliminar">Eliminar</button>
                    </form>

                </td>
            </tr>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </tbody>
</table>
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
