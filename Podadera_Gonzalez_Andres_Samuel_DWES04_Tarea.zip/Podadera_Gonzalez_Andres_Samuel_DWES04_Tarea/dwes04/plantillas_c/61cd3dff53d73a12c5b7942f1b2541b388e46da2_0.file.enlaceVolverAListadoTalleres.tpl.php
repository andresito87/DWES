<?php
/* Smarty version 4.4.1, created on 2024-03-02 17:51:01
  from 'C:\xampp\htdocs\dwes04\plantillas\enlaceVolverAListadoTalleres.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e358f5496f66_58640977',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '61cd3dff53d73a12c5b7942f1b2541b388e46da2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\dwes04\\plantillas\\enlaceVolverAListadoTalleres.tpl',
      1 => 1709393454,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e358f5496f66_58640977 (Smarty_Internal_Template $_smarty_tpl) {
?><a href='index.php'>Volver al listado de talleres</a><?php }
}
