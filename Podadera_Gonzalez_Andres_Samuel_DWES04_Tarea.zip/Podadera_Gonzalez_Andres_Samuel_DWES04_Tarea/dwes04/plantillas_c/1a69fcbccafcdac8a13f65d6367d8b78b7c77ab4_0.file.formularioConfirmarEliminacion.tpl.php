<?php
/* Smarty version 4.4.1, created on 2024-03-02 22:28:36
  from '/var/www/html/plantillas/formularioConfirmarEliminacion.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a814a68a27_40907741',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1a69fcbccafcdac8a13f65d6367d8b78b7c77ab4' => 
    array (
      0 => '/var/www/html/plantillas/formularioConfirmarEliminacion.tpl',
      1 => 1709400025,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:mostrarErrores.tpl' => 1,
    'file:enlaceVolverAListadoTalleres.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_65e3a814a68a27_40907741 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Confirmar eliminación"), 0, false);
?>
<div>
    <?php if ((isset($_smarty_tpl->tpl_vars['errores']->value))) {?>
        <?php $_smarty_tpl->_subTemplateRender("file:mostrarErrores.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('errores'=>$_smarty_tpl->tpl_vars['errores']->value), 0, false);
?>
    <?php }?>
    <form action="index.php?accion=borrar_taller" method="post"><label for="confirmar">Marque la casilla de verificación
            para confirmar la eliminación</label>
        <?php if ((isset($_smarty_tpl->tpl_vars['id']->value))) {?>
            <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
        <?php }?>
        <input type="checkbox" id="eliminar" name="eliminar" value="eliminar">
        <input type="hidden" name="confirmar" value="confirmar">
        <br>
        <input class="eliminar" type="submit" value="Confirmar elimninación">
    </form>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:enlaceVolverAListadoTalleres.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
