<?php
/* Smarty version 4.4.1, created on 2024-03-02 23:35:27
  from 'C:\xampp\htdocs\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\dwes04\plantillas\mostrarErrores.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a9af801d41_72512132',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11daa060474dc4f1120aa0e5418067fee0f8f585' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\\dwes04\\plantillas\\mostrarErrores.tpl',
      1 => 1709389043,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a9af801d41_72512132 (Smarty_Internal_Template $_smarty_tpl) {
?><div>
    <h2>Errores</h2>
    <ul>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['errores']->value, 'error');
$_smarty_tpl->tpl_vars['error']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->do_else = false;
?>
            <li><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</li>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </ul>
</div><?php }
}
