<?php
/* Smarty version 4.4.1, created on 2024-03-02 22:16:47
  from '/var/www/html/plantillas/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a54fba14b8_95522994',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5279d52c35069df085c76a8ce05f44b066f3836f' => 
    array (
      0 => '/var/www/html/plantillas/footer.tpl',
      1 => 1708795259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a54fba14b8_95522994 (Smarty_Internal_Template $_smarty_tpl) {
?></body>

</html><?php }
}
