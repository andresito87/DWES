<?php
/* Smarty version 4.4.1, created on 2024-03-02 17:51:31
  from 'C:\xampp\htdocs\dwes04\plantillas\mostrarErrores.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e35913ce7144_64231169',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '30b0f5f0976e6170c994a17762a98719bb4b49f8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\dwes04\\plantillas\\mostrarErrores.tpl',
      1 => 1709389043,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e35913ce7144_64231169 (Smarty_Internal_Template $_smarty_tpl) {
?><div>
    <h2>Errores</h2>
    <ul>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['errores']->value, 'error');
$_smarty_tpl->tpl_vars['error']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->do_else = false;
?>
            <li><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</li>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </ul>
</div><?php }
}
