<?php
/* Smarty version 4.4.1, created on 2024-03-02 22:16:47
  from '/var/www/html/plantillas/formularioFiltrarDia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a54f911ad0_69773639',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b7eab4256f945fe0877fd88d876d1de001a0f520' => 
    array (
      0 => '/var/www/html/plantillas/formularioFiltrarDia.tpl',
      1 => 1709399468,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a54f911ad0_69773639 (Smarty_Internal_Template $_smarty_tpl) {
?><form action="./index.php" method="post">
        <label for="dia_semana">Filtar por día de la semana(lunes - viernes):
                <input type="text" id="dia_semana" name="dia_semana">
        </label>
        <input type="submit" value="Filtrar">
</form><?php }
}
