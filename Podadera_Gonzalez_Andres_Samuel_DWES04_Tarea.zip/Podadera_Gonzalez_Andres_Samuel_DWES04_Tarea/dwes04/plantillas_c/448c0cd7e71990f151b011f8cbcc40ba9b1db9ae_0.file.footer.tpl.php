<?php
/* Smarty version 4.4.1, created on 2024-03-02 17:51:00
  from 'C:\xampp\htdocs\dwes04\plantillas\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e358f4410037_01693567',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '448c0cd7e71990f151b011f8cbcc40ba9b1db9ae' => 
    array (
      0 => 'C:\\xampp\\htdocs\\dwes04\\plantillas\\footer.tpl',
      1 => 1708795259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e358f4410037_01693567 (Smarty_Internal_Template $_smarty_tpl) {
?></body>

</html><?php }
}
