<?php
/* Smarty version 4.4.1, created on 2024-03-02 22:28:05
  from '/var/www/html/plantillas/enlaceVolverAListadoTalleres.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a7f545e257_80054434',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'aca9ee5fa75f47f048469a104dc8accd5feedd5f' => 
    array (
      0 => '/var/www/html/plantillas/enlaceVolverAListadoTalleres.tpl',
      1 => 1709393454,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a7f545e257_80054434 (Smarty_Internal_Template $_smarty_tpl) {
?><a href='index.php'>Volver al listado de talleres</a><?php }
}
