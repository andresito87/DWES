<?php
/* Smarty version 4.4.1, created on 2024-03-02 22:28:05
  from '/var/www/html/plantillas/mostrarErrores.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a7f536c3b8_60178949',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '91bc92fa3294f9f8afad634310db09d280ca7f16' => 
    array (
      0 => '/var/www/html/plantillas/mostrarErrores.tpl',
      1 => 1709389043,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a7f536c3b8_60178949 (Smarty_Internal_Template $_smarty_tpl) {
?><div>
    <h2>Errores</h2>
    <ul>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['errores']->value, 'error');
$_smarty_tpl->tpl_vars['error']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->do_else = false;
?>
            <li><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</li>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </ul>
</div><?php }
}
