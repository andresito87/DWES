<?php
/* Smarty version 4.4.1, created on 2024-03-02 23:35:20
  from 'C:\xampp\htdocs\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\dwes04\plantillas\formularioFiltrarDia.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a9a8d63864_48127229',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39f579d22dd64ab807e6d282a1c869489c294ad2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\\dwes04\\plantillas\\formularioFiltrarDia.tpl',
      1 => 1709399468,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a9a8d63864_48127229 (Smarty_Internal_Template $_smarty_tpl) {
?><form action="./index.php" method="post">
        <label for="dia_semana">Filtar por día de la semana(lunes - viernes):
                <input type="text" id="dia_semana" name="dia_semana">
        </label>
        <input type="submit" value="Filtrar">
</form><?php }
}
