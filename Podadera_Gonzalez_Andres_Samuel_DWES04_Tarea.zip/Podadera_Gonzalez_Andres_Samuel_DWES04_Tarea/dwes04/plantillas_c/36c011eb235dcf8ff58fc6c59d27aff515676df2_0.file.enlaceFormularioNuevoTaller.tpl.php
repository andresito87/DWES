<?php
/* Smarty version 4.4.1, created on 2024-03-02 22:16:47
  from '/var/www/html/plantillas/enlaceFormularioNuevoTaller.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a54fcaac40_39098869',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '36c011eb235dcf8ff58fc6c59d27aff515676df2' => 
    array (
      0 => '/var/www/html/plantillas/enlaceFormularioNuevoTaller.tpl',
      1 => 1708796025,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a54fcaac40_39098869 (Smarty_Internal_Template $_smarty_tpl) {
?><h2>
    <a href="index.php?accion=nuevo_taller_form">Click aquí para añadir
        nuevo taller</a>
</h2><?php }
}
