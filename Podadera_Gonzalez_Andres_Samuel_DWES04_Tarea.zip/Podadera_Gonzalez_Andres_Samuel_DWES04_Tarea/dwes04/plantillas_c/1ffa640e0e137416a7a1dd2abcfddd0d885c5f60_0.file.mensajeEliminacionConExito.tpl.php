<?php
/* Smarty version 4.4.1, created on 2024-03-02 18:18:43
  from 'C:\xampp\htdocs\dwes04\plantillas\mensajeEliminacionConExito.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e35f734a3489_14874638',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1ffa640e0e137416a7a1dd2abcfddd0d885c5f60' => 
    array (
      0 => 'C:\\xampp\\htdocs\\dwes04\\plantillas\\mensajeEliminacionConExito.tpl',
      1 => 1709332016,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:enlaceVolverAListadoTalleres.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_65e35f734a3489_14874638 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"Confirmación de eliminación de taller"), 0, false);
?>
<h1>Taller con id <?php echo $_smarty_tpl->tpl_vars['id']->value;?>
 eliminado con éxito</h1>
<?php $_smarty_tpl->_subTemplateRender("file:enlaceVolverAListadoTalleres.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
