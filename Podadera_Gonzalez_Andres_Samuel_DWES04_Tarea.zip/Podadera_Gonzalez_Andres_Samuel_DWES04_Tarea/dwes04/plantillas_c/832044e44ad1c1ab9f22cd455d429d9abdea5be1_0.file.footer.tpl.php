<?php
/* Smarty version 4.4.1, created on 2024-03-02 23:35:20
  from 'C:\xampp\htdocs\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\dwes04\plantillas\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.4.1',
  'unifunc' => 'content_65e3a9a8d787a2_39793534',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '832044e44ad1c1ab9f22cd455d429d9abdea5be1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Podadera_Gonzalez_Andres_Samuel_DWES04_Tarea\\dwes04\\plantillas\\footer.tpl',
      1 => 1708795259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65e3a9a8d787a2_39793534 (Smarty_Internal_Template $_smarty_tpl) {
?></body>

</html><?php }
}
