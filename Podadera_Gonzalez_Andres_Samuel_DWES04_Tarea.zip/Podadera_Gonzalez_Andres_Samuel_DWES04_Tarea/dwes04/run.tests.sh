#!/bin/bash
./vendor/bin/phpunit --color --testdox tests