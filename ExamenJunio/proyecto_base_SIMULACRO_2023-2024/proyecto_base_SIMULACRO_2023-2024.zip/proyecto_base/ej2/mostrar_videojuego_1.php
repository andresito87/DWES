<!DOCTYPE html>
<html lang='es'>
  <head>
    <meta charset='utf-8' />
    <title>Prueba Junio - BBDD</title>
  </head>
  <body>
    <h1>Mostrar videojuego por ID</h1>


  </body>
</html>
