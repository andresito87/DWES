<!DOCTYPE html>
<html lang='es'>
  <head>
    <meta charset='utf-8' />
    <title>Prueba Junio - BBDD</title>
  </head>
  <body>
    <h1>Prueba Junio - BBDD</h1>

    <ol>
      <li><a href='editar_videojuego.php'>Editar videojuego</a>.</li>
      <li><a href='mostrar_videojuego_1.php'>Mostrar videojuego</a>.</li>
    </ol>

  </body>
</html>
