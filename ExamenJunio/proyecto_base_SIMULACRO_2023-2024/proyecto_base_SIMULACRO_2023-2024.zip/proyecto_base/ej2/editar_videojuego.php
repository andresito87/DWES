<!DOCTYPE html>
<html lang='es'>
  <head>
    <meta charset='utf-8' />
    <title>Eliminar vivienda</title>
  </head>

  <?php
	require_once('conexion_bbdd.php');

  ?>

  <body>
    <h1>Editar videojuego</h1>

    <p>El videojuego con identificador 3 ha sido editado correctamente.</p>
  </body>
</html>
