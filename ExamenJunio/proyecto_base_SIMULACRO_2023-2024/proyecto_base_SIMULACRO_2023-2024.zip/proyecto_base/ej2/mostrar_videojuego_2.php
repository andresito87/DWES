<!DOCTYPE html>
<html lang='es'>
  <head>
    <meta charset='utf-8' />
    <title>Prueba Junio - BBDD</title>
  </head>
  
  <?php
    require_once('conexion_bbdd.php');

  ?>
  
  <body>
    <h1>Mostrar videojuego por ID</h1>

    <ul>
      <li>ID: </li>
      <li>Título: </li>
      <li>Desarrollador: </li>
      <li>Año de publicación: </li>
    </ul>

  </body>
</html>
