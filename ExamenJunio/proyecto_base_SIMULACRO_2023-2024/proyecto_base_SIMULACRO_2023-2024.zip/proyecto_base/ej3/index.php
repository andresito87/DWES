<?php

//Datos de los desarrolladores disponibles
$desarrolladores=[
    "Bungie",
    "Hidetaka Miyazaki",
    "Infinity Ward",
    "Ken Levine",
    "Markus Persson",
    "Nintendo",
    "Patrice Désilets",
    "Rockstar North",
    "Todd Howard",
    "Valve Corporation"
];

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
</head>
<body>
    
<form action="" method="post">
    <label for="desarrollador">
        Selecciona el desarrollador:
        <select name="desarrollador" id="desarrollador">
                            <option value="Bungie">Bungie</option>
                            <option value="Hidetaka Miyazaki">Hidetaka Miyazaki</option>
                            <option value="Infinity Ward">Infinity Ward</option>
                            <option value="Ken Levine">Ken Levine</option>
                            <option value="Markus Persson">Markus Persson</option>
                            <option value="Nintendo">Nintendo</option>
                            <option value="Patrice Désilets">Patrice Désilets</option>
                            <option value="Rockstar North">Rockstar North</option>
                            <option value="Todd Howard">Todd Howard</option>
                            <option value="Valve Corporation">Valve Corporation</option>
                        <option value="otro">Otro desarrollador</option>
            <option value="<?=uniqid();?>">DATO ERRÓNEO ALEATORIO</option>
        </select>
    </label>
    <input type="submit" value="Comenzar!">
</form>

<form action="" method="post">
    <label for="desarrollador_otro">
        Indique el nombre del desarrollador: <input type="text" name="desarrollador_otro" id="desarrollador_otro">        
    </label>
    <input type="submit" value="Enviar!">
</form>


<form action="" method="post">
    <label for="anio_publicacion">
        Indique el año de publicación: <input type="text" name="anio_publicacion" id="anio_publicacion">        
    </label>
    <input type="submit" value="Enviar!">
</form>


</body>
</html>