<a href="<?php echo e($href); ?>"> <?php echo e($slot); ?> </a>
<?php /**PATH C:\xampp\htdocs\dwes05Unidad\dwes05\resources\views/components/boton.blade.php ENDPATH**/ ?>