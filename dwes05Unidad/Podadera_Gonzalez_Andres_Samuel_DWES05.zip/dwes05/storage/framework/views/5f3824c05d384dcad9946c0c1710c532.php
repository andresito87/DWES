<input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>"
    <?php echo e($type === 'checkbox' && $checked ? 'checked' : ''); ?> />
<?php /**PATH C:\xampp\htdocs\dwes05Unidad\dwes05\resources\views/components/input.blade.php ENDPATH**/ ?>