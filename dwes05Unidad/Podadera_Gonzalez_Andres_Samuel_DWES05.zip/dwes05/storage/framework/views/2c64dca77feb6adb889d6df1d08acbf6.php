<html xmlns="http://www.w3.org/1999/xhtml" lang="es">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('titulo'); ?> - Respira</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilo.css')); ?>" />
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><?php if (isset($component)) { $__componentOriginal9f9a106a37a0c3572d0517b4822108fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f9a106a37a0c3572d0517b4822108fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton','data' => ['href' => route('ubicaciones')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('boton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('ubicaciones'))]); ?>Lista de ubicaciones <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f9a106a37a0c3572d0517b4822108fd)): ?>
<?php $attributes = $__attributesOriginal9f9a106a37a0c3572d0517b4822108fd; ?>
<?php unset($__attributesOriginal9f9a106a37a0c3572d0517b4822108fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f9a106a37a0c3572d0517b4822108fd)): ?>
<?php $component = $__componentOriginal9f9a106a37a0c3572d0517b4822108fd; ?>
<?php unset($__componentOriginal9f9a106a37a0c3572d0517b4822108fd); ?>
<?php endif; ?></li>
                <li><a href="<?php echo e(route('crear_ubicacion')); ?>" dusk="botonCrearUbicacion">Crear nueva ubicación</a></li>
                <li><?php if (isset($component)) { $__componentOriginal9f9a106a37a0c3572d0517b4822108fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f9a106a37a0c3572d0517b4822108fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.boton','data' => ['href' => route('talleres')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('boton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('talleres'))]); ?>Lista de Talleres Con Inertia/VUE <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f9a106a37a0c3572d0517b4822108fd)): ?>
<?php $attributes = $__attributesOriginal9f9a106a37a0c3572d0517b4822108fd; ?>
<?php unset($__attributesOriginal9f9a106a37a0c3572d0517b4822108fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f9a106a37a0c3572d0517b4822108fd)): ?>
<?php $component = $__componentOriginal9f9a106a37a0c3572d0517b4822108fd; ?>
<?php unset($__componentOriginal9f9a106a37a0c3572d0517b4822108fd); ?>
<?php endif; ?></li>
                <li id="inicio"><a href="<?php echo e(route('principal')); ?>">Volver a Inicio</a></li>
            </ul>
        </nav>
    </header>
    <?php echo $__env->yieldContent('contenido'); ?>


    <footer>Hecho con 💛 por <a href="https://github.com/andresito87" target="_blank"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('codicon-github'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></a>
    </footer>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\dwes05Unidad\dwes05\resources\views/layouts/base.blade.php ENDPATH**/ ?>