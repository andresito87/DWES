<form action="<?php echo e($action); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <h2><?php echo e($titulo); ?></h2>
    <div class="campos">
        <?php echo e($campos); ?>

    </div>
    <div class="boton">
        <?php echo e($boton); ?>

    </div>
</form>
<?php /**PATH C:\xampp\htdocs\dwes05Unidad\dwes05\resources\views/components/formulario.blade.php ENDPATH**/ ?>