<label for="<?php echo e($for); ?>"><?php echo e($slot); ?></label>
<?php /**PATH C:\xampp\htdocs\dwes05Unidad\dwes05\resources\views/components/label.blade.php ENDPATH**/ ?>