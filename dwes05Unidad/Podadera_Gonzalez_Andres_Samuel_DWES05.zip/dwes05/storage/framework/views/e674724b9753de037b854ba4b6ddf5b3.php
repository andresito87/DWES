
<?php $__env->startSection('titulo', 'Detalles de ubicación'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="detalles">
        <p><strong>Nombre:</strong> <?php echo e($ubicacion->nombre); ?></p>
        <p><strong>Descripción:</strong> <?php echo e($ubicacion->descripcion); ?></p>
        <p><strong>Días:</strong> <?php echo e($ubicacion->dias); ?></p>
    </div>
    <?php if($ubicacion->talleres->isEmpty()): ?>
        <h3>No hay talleres registrados en esta ubcación</h3>
    <?php else: ?>
        <h3>Lista de talleres:</h3>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Dia de la semana</th>
                    <th>Hora de Inicio</th>
                    <th>Hora de Fin</th>
                    <th>Cupo</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ubicacion->talleres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($taller->nombre); ?></td>
                        <td><?php echo e($taller->descripcion); ?></td>
                        <td><?php echo e($taller->dia_semana); ?></td>
                        <td><?php echo e($taller->hora_inicio); ?></td>
                        <td><?php echo e($taller->hora_fin); ?></td>
                        <td><?php echo e($taller->cupo_maximo); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dwes05Unidad\dwes05\resources\views/ubicaciones/detalleubicacion.blade.php ENDPATH**/ ?>