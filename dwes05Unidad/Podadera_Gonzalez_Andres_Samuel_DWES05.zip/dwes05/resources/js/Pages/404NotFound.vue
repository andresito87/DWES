<script setup>
import Layout from "@/Layouts/TallerLayout.vue";
</script>

<template>
    <Layout>
        <h1>404 No Encontrado</h1>
        <p>La página que buscas no existe.</p>
    </Layout>
</template>

<style scoped>
h1,
p {
    text-align: center;
    margin-top: 50px;
}
</style>
