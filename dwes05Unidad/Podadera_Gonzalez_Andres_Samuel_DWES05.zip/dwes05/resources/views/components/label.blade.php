<label for="{{ $for }}">{{ $slot }}</label>
