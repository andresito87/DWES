<input type="{{ $type }}" name="{{ $name }}" value="{{ $value }}"
    {{ $type === 'checkbox' && $checked ? 'checked' : '' }} />
