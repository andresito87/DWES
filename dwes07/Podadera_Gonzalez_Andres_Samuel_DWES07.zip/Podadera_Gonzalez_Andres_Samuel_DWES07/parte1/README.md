## Aplicación de análisis de archivos con VirusTotal

Aplicación web que permite analizar archivos con la API de VirusTotal. La aplicación permite subir archivos y obtener un reporte de análisis de VirusTotal.

## Intrucciones de uso

1. Clonar el repositorio
2. Crear un entorno virtual .env con la clave de la API de VirusTotal
3. Instalar las dependencias con `composer install`
4. Servir la aplicación desde XAMPP o cualquier otro servidor local
5. Acceder a la aplicación desde el navegador, archivo index.php
